import UIReducer from './slices/ui/UISlice'

const rootReducer = {
	UI: UIReducer,
}

export default rootReducer
